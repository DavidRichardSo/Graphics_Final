package ray.renderer;

import ray.material.Material;
import ray.math.Point2;
import ray.math.Vector3;
import ray.misc.Color;
import ray.misc.IntersectionRecord;
import ray.misc.LuminaireSamplingRecord;
import ray.misc.Ray;
import ray.misc.Scene;
import ray.sampling.SampleGenerator;
import ray.math.Geometry;
import ray.brdf.BRDF;

/**
 * A renderer that computes radiance due to emitted and directly reflected light only.
 * 
 * @author cxz (at Columbia)
 */
public class DirectOnlyRenderer implements Renderer {
    
    /**
     * This is the object that is responsible for computing direct illumination.
     */
    DirectIlluminator direct = null;
        
    /**
     * The default is to compute using uninformed sampling wrt. projected solid angle over the hemisphere.
     */
    public DirectOnlyRenderer() {
        this.direct = new ProjSolidAngleIlluminator();
    }
    
    
    /**
     * This allows the rendering algorithm to be selected from the input file by substituting an instance
     * of a different class of DirectIlluminator.
     * @param direct  the object that will be used to compute direct illumination
     */
    public void setDirectIlluminator(DirectIlluminator direct) {
        this.direct = direct;
    }

    
    public void rayRadiance(Scene scene, Ray ray, SampleGenerator sampler, int sampleIndex, Color outColor) {

        // // Part 3 Works
     //    // W4160 TODO (A)
    	// // In this function, you need to implement your direct illumination rendering algorithm
    	// //
    	// // you need:
    	// // 1) compute the emitted light radiance from the current surface if the surface is a light surface
    	// // 2) direct reflected radiance from other lights. This is by implementing the function
    	// //    ProjSolidAngleIlluminator.directIlluminaiton(...), and call direct.directIllumination(...) in this
    	// //    function here.

        // find if the ray intersect with any surface
        IntersectionRecord iRec = new IntersectionRecord();

        Point2 directSeed = new Point2();
        sampler.sample(1, sampleIndex, directSeed);     // this random variable is for incident direction
            
        // Generate a random incident direction
        Vector3 incDir = new Vector3();
        
        if (scene.getFirstIntersection(iRec, ray)) {

            direct.directIllumination(scene, incDir, new Vector3(), iRec, directSeed, outColor);
            return;
        }
        
        scene.getBackground().evaluate(ray.direction, outColor);

        //    // find if the ray intersect with any surface
        // IntersectionRecord iRec = new IntersectionRecord();
        // Color radiance = new Color();
        
        // if (scene.getFirstIntersection(iRec, ray)) {

        //     if (iRec.surface.getMaterial().isEmitter())
        //     {
        //         outColor.set(1,1,1);
        //         return;
        //     }
            
        //     Point2 directSeed = new Point2();
        //     sampler.sample(1, sampleIndex, directSeed);     // this random variable is for incident direction
            
        //     // Generate a random incident direction
        //     Vector3 incDir = new Vector3();
        //     Geometry.squareToHemisphere(directSeed, incDir);
        //     iRec.frame.frameToCanonical(incDir);
            
        //     Ray shadowRay = new Ray(iRec.frame.o, incDir);
        //     shadowRay.makeOffsetRay();
            
        //     // if ( !scene.getFirstIntersection(iRec, shadowRay) ) {
        //     //     outColor.set(0.8);
        //     // } else {
        //     //     // determine the length of the shadow ray
        //     //     Vector3 exts = scene.getBoundingBoxExtents();
        //     //     if ( iRec.t > .1 * exts.length() ) 
        //     //         outColor.set(0.8);
        //     //     else 
        //     //         outColor.set(0.);
        //     // }

        //     // First attempt -> stick with random

        //     IntersectionRecord second_Rec = new IntersectionRecord(); 

        //     if (scene.getFirstIntersection(second_Rec, shadowRay)) 
        //     {
        //         // is emittor
        //         if (second_Rec.surface.getMaterial().isEmitter())
        //         {
        //             Vector3 emitDir = new Vector3(-shadowRay.direction.x, -shadowRay.direction.y, -shadowRay.direction.z);
        //             emittedRadiance(second_Rec, emitDir, radiance);
        //             // BRDF for surface in question 
        //             BRDF temp = iRec.surface.getMaterial().getBRDF(iRec);
        //             // Get color, assuming lambertian (needs change for Microfacets?)
        //             Color tempColor = new Color(0,0,0);
        //             temp.evaluate(iRec.frame, new Vector3 (0, 0, 1), new Vector3 (0,0,1), tempColor);
        //             outColor.set(radiance.r * tempColor.r, radiance.g * tempColor.g, radiance.b * tempColor.b);
        //         }
        //         else
        //         {
        //             double inc_dot_norm = incDir.x * second_Rec.frame.w.x + incDir.y * second_Rec.frame.w.y + incDir.z * second_Rec.frame.w.z;
        //             Vector3 newInc = new Vector3(-2 * inc_dot_norm * second_Rec.frame.w.x + incDir.x, -2 * inc_dot_norm * second_Rec.frame.w.y + incDir.y, -2 * inc_dot_norm * second_Rec.frame.w.z + incDir.z);          
        //             Ray newRay = new Ray(second_Rec.frame.o, newInc);
        //             IntersectionRecord thirdRec = new IntersectionRecord();

        //             if (scene.getFirstIntersection(thirdRec, newRay))
        //             {
        //                 Vector3 emitDir = new Vector3(-newRay.direction.x, -newRay.direction.y, -newRay.direction.z);
        //                 emittedRadiance(thirdRec, emitDir, radiance);
        //                 // BRDF for surface in question 
        //                 BRDF temp = iRec.surface.getMaterial().getBRDF(iRec);
        //                 // Get color, assuming lambertian (needs change for Microfacets?)
        //                 Color tempColor = new Color(0,0,0);
        //                 temp.evaluate(iRec.frame, new Vector3 (0, 0, 1), new Vector3 (0,0,1), tempColor);
        //                 BRDF temp_2 = iRec.surface.getMaterial().getBRDF(second_Rec);
        //                 // Get color, assuming lambertian (needs change for Microfacets?)
        //                 Color tempColor_2 = new Color(0,0,0);
        //                 temp.evaluate(second_Rec.frame, new Vector3 (0, 0, 1), new Vector3 (0,0,1), tempColor_2);
        //                 outColor.set(radiance.r * tempColor.r * tempColor_2.r, radiance.g * tempColor.g * tempColor_2.g, radiance.b * tempColor.b * tempColor_2.b);
        //             }
        //         }
        //     }

        //     return;
        // }
        
        // scene.getBackground().evaluate(ray.direction, outColor);


    }

    
    /**
     * Compute the radiance emitted by a surface.
     * @param iRec      Information about the surface point being shaded
     * @param dir          The exitant direction (surface coordinates)
     * @param outColor  The emitted radiance is written to this color
     */
    protected void emittedRadiance(IntersectionRecord iRec, Vector3 dir, Color outColor) {
    	// W4160 TODO (A)
        // If material is emitting, query it for emission in the relevant direction.
        // If not, the emission is zero.
    	// This function should be called in the rayRadiance(...) method above

        if (iRec.surface.getMaterial().isEmitter())
        {
            LuminaireSamplingRecord temp = new LuminaireSamplingRecord();
            temp.set(iRec);
            temp.emitDir = dir;
            iRec.surface.getMaterial().emittedRadiance(temp,outColor);

            return;
        }
        outColor.set(0,0,0);
    }
}
