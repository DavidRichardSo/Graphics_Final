package ray.renderer;

import ray.brdf.BRDF;
import ray.material.Material;
import ray.math.Geometry;
import ray.math.Point2;
import ray.math.Vector3;
import ray.misc.Color;
import ray.misc.IntersectionRecord;
import ray.misc.Scene;
import ray.misc.Ray;
import ray.misc.LuminaireSamplingRecord;

/**
 * This class computes direct illumination at a surface by the simplest possible approach: it estimates
 * the integral of incident direct radiance using Monte Carlo integration with a uniform sampling
 * distribution.
 * 
 * The class has two purposes: it is an example to serve as a starting point for other methods, and it
 * is a useful base class because it contains the generally useful <incidentRadiance> function.
 * 
 * @author srm, Changxi Zheng (at Columbia)
 */
public class ProjSolidAngleIlluminator extends DirectIlluminator {
    
    
    public void directIllumination(Scene scene, Vector3 incDir, Vector3 outDir, 
            IntersectionRecord iRec, Point2 seed, Color outColor) {
        // W4160 TODO (A)
    	// This method computes a Monte Carlo estimate of reflected radiance due to direct illumination.  It
        // generates samples uniformly wrt. the projected solid angle measure:
        //
        //    f = brdf * radiance
        //    p = 1 / pi
        //    g = f / p = brdf * radiance * pi
        //
        // The same code could be interpreted as an integration wrt. solid angle, as follows:
        //
        //    f = brdf * radiance * cos_theta
        //    p = cos_theta / pi
        //    g = f / p = brdf * radiance * pi
    	// 
    	// As a hint, here are a few steps when I code this function
    	// 1. Generate a random incident direction according to proj solid angle
        //    pdf is constant 1/pi
    	// 2. Find incident radiance from that direction
    	// 3. Estimate reflected radiance using brdf * radiance / pdf = pi * brdf * radiance
        Color radiance = new Color();
        Geometry.squareToPSAHemisphere(seed, incDir);

        if (iRec.surface.getMaterial().isEmitter())
        {
            outColor.set(1,1,1);
            return;
        }

        iRec.frame.frameToCanonical(incDir);
        
        Ray shadowRay = new Ray(iRec.frame.o, incDir);
        shadowRay.makeOffsetRay();

        IntersectionRecord second_Rec = new IntersectionRecord(); 

        if (scene.getFirstIntersection(second_Rec, shadowRay)) 
        {
            Vector3 emitDir = new Vector3(-shadowRay.direction.x, -shadowRay.direction.y, -shadowRay.direction.z);
            emittedRadiance(second_Rec, emitDir, radiance);
            // BRDF for surface in question 
            BRDF temp = iRec.surface.getMaterial().getBRDF(iRec);
            // Get color, assuming lambertian (needs change for Microfacets?)
            Color tempColor = new Color(0,0,0);
            temp.evaluate(iRec.frame, new Vector3 (0, 0, 1), new Vector3 (0,0,1), tempColor);
            outColor.set(radiance.r * tempColor.r * Math.PI, radiance.g * tempColor.g * Math.PI, radiance.b * tempColor.b * Math.PI);
        }
    }

    protected void emittedRadiance(IntersectionRecord iRec, Vector3 dir, Color outColor) {
    // W4160 TODO (A)
    // If material is emitting, query it for emission in the relevant direction.
    // If not, the emission is zero.
    // This function should be called in the rayRadiance(...) method above

    if (iRec.surface.getMaterial().isEmitter())
    {
        LuminaireSamplingRecord temp = new LuminaireSamplingRecord();
        temp.set(iRec);
        temp.emitDir = dir;
        iRec.surface.getMaterial().emittedRadiance(temp,outColor);

        return;
    }
        outColor.set(0,0,0);
    }
    
}
