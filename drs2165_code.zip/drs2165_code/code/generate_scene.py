import sys

try:
	f1 = open(sys.argv[1],'r')
	f2 = open(sys.argv[2],'w')
	replacement_line = int(sys.argv[3])
	horse_number = int(sys.argv[4])
except:
	"Usage: <backup file> <file to write> <number of line to change> <horse_number>"

count  = 1 # file lines are 1 indexed
for line in f1:
	if count != replacement_line:
		f2.write(line)
	else:
		f2.write("\t\t<data>horse_")
		f2.write(str(horse_number))
		f2.write(".msh</data>\n")
	count += 1

f1.close()
f2.close()
